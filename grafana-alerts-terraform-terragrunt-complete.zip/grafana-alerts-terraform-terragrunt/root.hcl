# Example GitLab-managed Terraform HTTP state backend.
# State names are derived from the Terragrunt unit path. Keep each independently
# managed Grafana rule group in its own state.
remote_state {
  backend = "http"

  generate = {
    path      = "backend.tf"
    if_exists = "overwrite_terragrunt"
  }

  config = {
    address        = "${get_env("CI_API_V4_URL", "https://gitlab.com/api/v4")}/projects/${get_env("CI_PROJECT_ID", "REPLACE_WITH_GITLAB_PROJECT_ID")}/terraform/state/${replace(path_relative_to_include(), "/", "-")}"
    lock_address   = "${get_env("CI_API_V4_URL", "https://gitlab.com/api/v4")}/projects/${get_env("CI_PROJECT_ID", "REPLACE_WITH_GITLAB_PROJECT_ID")}/terraform/state/${replace(path_relative_to_include(), "/", "-")}/lock"
    unlock_address = "${get_env("CI_API_V4_URL", "https://gitlab.com/api/v4")}/projects/${get_env("CI_PROJECT_ID", "REPLACE_WITH_GITLAB_PROJECT_ID")}/terraform/state/${replace(path_relative_to_include(), "/", "-")}/lock"
    lock_method    = "POST"
    unlock_method  = "DELETE"
    retry_wait_min = 5
  }
}
