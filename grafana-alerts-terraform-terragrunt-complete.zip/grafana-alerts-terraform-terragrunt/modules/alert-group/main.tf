resource "grafana_rule_group" "this" {
  name             = var.group_name
  folder_uid       = var.folder_uid
  interval_seconds = var.evaluation_interval_seconds

  # Set org_id only when explicitly supplied.
  org_id = var.org_id

  dynamic "rule" {
    for_each = var.rules
    iterator = rule_item

    content {
      uid            = rule_item.value.uid
      name           = rule_item.value.name
      condition      = rule_item.value.condition
      for            = rule_item.value.pending_for
      no_data_state  = rule_item.value.no_data_state
      exec_err_state = rule_item.value.exec_err_state
      is_paused      = rule_item.value.is_paused
      labels         = rule_item.value.labels
      annotations    = rule_item.value.annotations

      dynamic "data" {
        for_each = rule_item.value.data
        iterator = data_item

        content {
          ref_id         = data_item.value.ref_id
          datasource_uid = data_item.value.datasource_uid
          query_type     = data_item.value.query_type

          relative_time_range {
            from = data_item.value.relative_time_range.from
            to   = data_item.value.relative_time_range.to
          }

          # The model must represent the complete Grafana query/expression
          # model for this stage. Export and preserve it for production use.
          model = jsonencode(data_item.value.model)
        }
      }
    }
  }
}
