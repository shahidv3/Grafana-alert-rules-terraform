variable "folder_uid" {
  description = "UID of the existing Grafana folder that will contain the rule group."
  type        = string
}

variable "group_name" {
  description = "Grafana alert rule group name."
  type        = string
}

variable "org_id" {
  description = "Grafana organization ID, when required by the target instance."
  type        = string
  default     = null
  nullable    = true
}

variable "evaluation_interval_seconds" {
  description = "Evaluation cadence shared by every rule in this group."
  type        = number
  default     = 60

  validation {
    condition     = var.evaluation_interval_seconds >= 10
    error_message = "Use an evaluation interval of at least 10 seconds, subject to your Grafana configuration."
  }
}

variable "rules" {
  description = "Complete alert rule definitions, including all query and expression stages."
  type = list(object({
    uid            = string
    name           = string
    condition      = string
    pending_for    = string
    no_data_state  = string
    exec_err_state = string
    is_paused      = bool
    labels         = map(string)
    annotations    = map(string)
    data = list(object({
      ref_id         = string
      datasource_uid = string
      query_type     = optional(string, "")
      relative_time_range = object({
        from = number
        to   = number
      })
      model = any
    }))
  }))

  validation {
    condition     = length(var.rules) > 0
    error_message = "At least one rule is required for a Grafana rule group."
  }
}
