variable "grafana_url" {
  description = "Grafana Cloud stack URL, supplied via TF_VAR_grafana_url."
  type        = string
}

variable "grafana_auth" {
  description = "Grafana service-account token, supplied via TF_VAR_grafana_auth."
  type        = string
  sensitive   = true
}

provider "grafana" {
  url  = var.grafana_url
  auth = var.grafana_auth
}
