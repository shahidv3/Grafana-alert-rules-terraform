output "rule_group_id" {
  description = "Provider ID of the managed Grafana alert rule group."
  value       = grafana_rule_group.this.id
}

output "rule_group_name" {
  description = "Name of the managed Grafana alert rule group."
  value       = grafana_rule_group.this.name
}
