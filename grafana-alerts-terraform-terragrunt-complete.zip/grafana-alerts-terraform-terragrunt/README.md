# Grafana Cloud alert rules with Terraform + Terragrunt

This repository is a guarded **pilot scaffold**, not a claim that the example PromQL is production-validated. It creates a new rule group with two paused PostgreSQL example rules. Do not enable them until the live rule JSON, datasource UID, folder UID, and PromQL have been checked.

## Pipeline stages

- **Validate:** Terraform formatting, initialization, provider validation, and a non-refreshing preflight plan.
- **Plan:** generates `alert-rules.tfplan` plus a readable `alert-rules-plan.txt` artifact.
- **Apply:** manual job on the default branch only; applies the saved plan artifact, not a newly calculated plan.
- **Verify:** reminds the operator to confirm the new group and rule state in Grafana Cloud.

The plan job carries `.terragrunt-cache/` as an artifact so the Terragrunt-generated root module remains available to the apply job. The pipeline pins Terraform and Terragrunt versions. Test this exact artifact flow in a non-production GitLab project before adopting it for production.

## GitLab setup

Create CI/CD variables:

- `GRAFANA_URL`: full Grafana Cloud stack URL, e.g. `https://YOUR-STACK.grafana.net`
- `GRAFANA_AUTH`: Grafana service-account token; masked and protected
- If using a self-managed GitLab instance, confirm `CI_API_V4_URL` resolves correctly.
- Enable GitLab Terraform state for the project and confirm the job token has the required state permissions. The example uses `CI_JOB_TOKEN` for the HTTP backend; GitLab project configuration and version may require a different authorized state credential.

Protect the default branch and the `production` environment. Restrict who can run the manual apply job. Require merge-request review for changes to alert definitions. Do not store secrets in the repository or Terragrunt inputs.

## Configure before the first pipeline

Edit `live/prod/postgres-alerts/terragrunt.hcl`:

1. Replace the folder UID placeholder.
2. Replace the Prometheus datasource UID placeholders.
3. Verify the exact query expressions and data-model JSON against the live Grafana alert-rule export and Grafana Explore.
4. Confirm the organization ID.
5. Keep `is_paused = true` until a separate activation change is reviewed.
6. Confirm that the selected Grafana service account has only the necessary alerting permissions.

The example expressions are candidates only:
- `pg_exporter_last_scrape_error > 0`
- `increase(pg_stat_database_deadlocks[5m]) >= 1`

The review spreadsheet was transcribed from incomplete/truncated query views; these are not guaranteed to match your live metric names or full Grafana query models.

## Run locally

From `live/prod/postgres-alerts`:

```bash
terragrunt init
terragrunt validate
terragrunt plan
```

Set `TF_VAR_grafana_url` and `TF_VAR_grafana_auth` in your shell. For remote state, configure the required GitLab HTTP backend environment and project ID. Do not use local state for shared production management.

## Safety and state

- A Grafana `grafana_rule_group` resource manages the complete rule group. Do not configure only a subset of an existing group and apply it.
- The pilot intentionally creates a **new** group. It does not import or modify the existing production groups.
- For an existing group, export its complete live definition, preserve every rule and query stage, import into a dedicated state, and reconcile drift with a plan before changing anything.
- Never apply a plan whose code, provider version, Terragrunt version, or configuration has changed since planning.
- `resource_group` serializes these pipeline jobs, but verify state locking works in your GitLab installation.
- The plan artifact and cache are temporary, expire after one day, and may contain internal configuration. Keep project/job artifact access appropriately restricted.

## Recovery

There is no safe generic automatic rollback for alert rules. If an apply causes an issue, pause the affected rule in Grafana Cloud if appropriate, inspect the current state and live group, then submit a reviewed corrective Terraform change. Do not delete state or run `terraform state rm` as a routine rollback.

## Existing rules: import carefully

For an existing group:
1. Export its complete JSON/Terraform representation.
2. Preserve all rules, UIDs, query stages, labels, annotations, no-data/error behavior, and notification settings.
3. Use a dedicated Terragrunt unit/state for the group.
4. Import using the exact identifier format documented for the installed Grafana provider version; do not assume a universal import string.
5. Run plan and reconcile drift before applying.
6. Change only reviewed fields and verify the plan contains no unexpected deletions.
