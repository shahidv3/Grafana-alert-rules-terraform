# Pre-deployment checklist

- [ ] Test the pipeline in a non-production GitLab project.
- [ ] Confirm Terraform state initialization, locking, and permissions.
- [ ] Protect the default branch and `production` environment.
- [ ] Configure masked/protected `GRAFANA_URL` and `GRAFANA_AUTH`.
- [ ] Replace every folder and datasource UID placeholder.
- [ ] Validate both PromQL expressions in Grafana Explore.
- [ ] Compare the full query model and rule JSON with the live Grafana rule export.
- [ ] Confirm the plan creates only the intended new paused pilot group.
- [ ] Review `alert-rules-plan.txt` and approve the merge request.
- [ ] Trigger the manual apply only after approval.
- [ ] Verify group, rules, evaluation state, labels, annotations, and notifications in Grafana.
- [ ] Keep rules paused until the monitoring owner approves activation.
