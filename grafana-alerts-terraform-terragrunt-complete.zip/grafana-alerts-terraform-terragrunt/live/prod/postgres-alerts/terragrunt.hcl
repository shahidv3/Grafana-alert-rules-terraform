terraform {
  source = "../../../modules/alert-group"
}

include "root" {
  path = find_in_parent_folders("root.hcl")
}

inputs = {
  folder_uid = "REPLACE_WITH_POSTGRES_FOLDER_UID"
  group_name = "postgres-alerts-terraform-pilot"
  org_id     = "1"

  evaluation_interval_seconds = 60

  rules = [
    {
      uid            = "tf-pilot-pg-exporter-errors"
      name           = "[TF PILOT] PostgreSQLExporterErrors"
      condition      = "A"
      pending_for    = "2m"
      no_data_state  = "NoData"
      exec_err_state = "Error"
      is_paused      = true

      labels = {
        severity   = "warning"
        team       = "database"
        managed_by = "terraform-pilot"
      }

      annotations = {
        summary     = "PostgreSQL exporter scrape errors detected"
        description = "Exporter errors indicate a telemetry gap and do not by themselves prove PostgreSQL is unavailable."
      }

      data = [
        {
          ref_id         = "A"
          datasource_uid = "REPLACE_WITH_PROMETHEUS_DATASOURCE_UID"
          query_type     = ""

          relative_time_range = {
            from = 300
            to   = 0
          }

          model = {
            datasource = {
              type = "prometheus"
              uid  = "REPLACE_WITH_PROMETHEUS_DATASOURCE_UID"
            }
            editorMode    = "code"
            expr          = "pg_exporter_last_scrape_error > 0"
            instant       = true
            intervalMs    = 1000
            maxDataPoints = 43200
            range         = false
            refId         = "A"
          }
        }
      ]
    },
    {
      uid            = "tf-pilot-pg-deadlocks"
      name           = "[TF PILOT] PostgreSQLDeadlocks"
      condition      = "A"
      pending_for    = "0s"
      no_data_state  = "NoData"
      exec_err_state = "Error"
      is_paused      = true

      labels = {
        severity   = "warning"
        team       = "database"
        managed_by = "terraform-pilot"
      }

      annotations = {
        summary     = "A new PostgreSQL deadlock was observed"
        description = "Validate the metric name and workload impact before enabling this rule."
      }

      data = [
        {
          ref_id         = "A"
          datasource_uid = "REPLACE_WITH_PROMETHEUS_DATASOURCE_UID"
          query_type     = ""

          relative_time_range = {
            from = 300
            to   = 0
          }

          model = {
            datasource = {
              type = "prometheus"
              uid  = "REPLACE_WITH_PROMETHEUS_DATASOURCE_UID"
            }
            editorMode    = "code"
            expr          = "increase(pg_stat_database_deadlocks[5m]) >= 1"
            instant       = true
            intervalMs    = 1000
            maxDataPoints = 43200
            range         = false
            refId         = "A"
          }
        }
      ]
    }
  ]
}
